# metadata
__version__ = "0.1.0"

# which import for this module
from .validate_functions import validate_vict_sex, validate_vict_age
from .stats_functions import mean_age, median_age

print("Welcome to My Validate and Stats Package!"
